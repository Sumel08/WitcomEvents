//# sourceMappingURL=model.search.js.map
DataTable.models.oSearch={bCaseInsensitive:!0,sSearch:"",bRegex:!1,bSmart:!0};