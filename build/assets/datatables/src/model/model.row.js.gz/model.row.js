//# sourceMappingURL=model.row.js.map
DataTable.models.oRow={nTr:null,_aData:[],_aSortData:[],_anHidden:[],_sRowStripe:""};