//# sourceMappingURL=tables.js.map
$(document).ready(function(){$("#example").dataTable()});